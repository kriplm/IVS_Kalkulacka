﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Mathlib;


namespace Kalkulačka_IVS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            this.KeyPreview = true;
            this.KeyPress +=
            new KeyPressEventHandler(Form1_KeyPress);
        }

        IVSMath ivsmath = new IVSMath();

        public Button znam;

        public bool vstup=false;

        void znam_tmp(Button znam)
        {
            try
            {
                if (vstup == false)
                {
                    lblpredvýsledek.Text = lblpredvýsledek.Text.Remove(lblpredvýsledek.Text.Length - 1) + znam.Text;
                }
                else
                {
                    if (lblpredvýsledek.Text == "0")
                    {
                        lblpredvýsledek.Text = lblvysledek.Text + znam.Text;
                    }
                    else
                    {
                        char znak = lblpredvýsledek.Text[lblpredvýsledek.Text.Length - 1];
                        if (char.IsNumber(znak))
                        {
                            lblpredvýsledek.Text = lblpredvýsledek.Text + znam.Text;
                        }
                        else
                        {
                            lblpredvýsledek.Text = lblpredvýsledek.Text.Remove(lblpredvýsledek.Text.Length - 1);
                            double meziVysledek = vysledek(Convert.ToDouble(lblpredvýsledek.Text), Convert.ToDouble(lblvysledek.Text), znak);
                            lblpredvýsledek.Text = Convert.ToString(meziVysledek) + znam.Text;
                        }
                    }
                    lblvysledek.Text = "0";
                }
                vstup = false;
            }
            catch (Exception)
            {
                
            }
        }

        void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 48 && e.KeyChar <= 57)|| e.KeyChar ==44)
            {
                if (lblvysledek.Text == "0" && e.KeyChar != 44)
                    lblvysledek.Text = e.KeyChar.ToString();
                else
                {
                    if (lblvysledek.Text.IndexOf(",", 0, lblvysledek.Text.Length) == -1)
                        lblvysledek.Text += e.KeyChar.ToString();
                    else if ( e.KeyChar != 44)
                    {
                        lblvysledek.Text += e.KeyChar.ToString();
                    }

                }
                 
            }
            else if (e.KeyChar == 43)
            {
                //show("+");
                znam_tmp(btnplus);
            }
            else if (e.KeyChar == 45)
            {
                // show("-");
                znam_tmp(btnminus);
            }
            else if (e.KeyChar == 42)
            {
                //    show("*");
                znam_tmp(btnkrat);
            }
            else if (e.KeyChar == 47)
            {
                //    show("/");
                znam_tmp(btndel);
            }
            else if (e.KeyChar == 79 || e.KeyChar == 111)
            {
                znam_tmp(btnodmocnina);
            }
            else if (e.KeyChar == 37)
            {
                znam_tmp(btnmodulo);
            }
            else if (e.KeyChar == 33)
            {
                znam_tmp(btnfaktorial);
            }
            else if (e.KeyChar == 127 )
            {
                if (lblvysledek.Text.Length > 0)
                {
                    lblvysledek.Text = lblvysledek.Text.Remove(lblvysledek.Text.Length - 1, 1);
                }

                if (lblvysledek.Text == "")
                {
                    lblvysledek.Text = "0";
                }
            }
        }

        double vysledek(double a, double b,char znak)
        {
            double vys=0;

            switch (znak)
            {
                case '+':
                    vys=ivsmath.Scitani(a, b);
                    break;

                case '-':
                    vys = ivsmath.Odcitani(a, b);
                    break;

                case '*':
                    vys = ivsmath.Nasobeni(a, b);
                    break;

                case '/':
                    //if( b == 0)
                    //{
                    //    MessageBox.Show("Nelze dělit nulou!");
                    //    vys = 0;
                    //    break;
                    //}

                    vys = ivsmath.Deleni(a, b);
                    break;

                case '%':
                    vys = ivsmath.Modulo(a, b);
                    break;

                case '!':
                    try
                    {
                        vys = ivsmath.Faktorial(a);
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("err!");
                    }
                    break;

                case '√':
                    if (a == 0)
                    {
                        MessageBox.Show("Nelze dělit nulou!");
                        vys = 0;
                        break;
                    }
                    if ((b <= 0) && ((a % 2) == 0))
                    {
                        MessageBox.Show("Nelze odmocnit nulové nebo záporné číslo!");
                        vys = 0;
                        break;
                    }
                    vys = ivsmath.Odmocnina(a, b);
                    break;

                case '^':
                    vys = ivsmath.Mocnina(a, b);
                    break;
            }

            return vys;
        }
        

        private void number_click(object sender, EventArgs e)
        {
            Button num = (Button)sender;
            vstup = true;

            if (lblvysledek.Text == "0")
            {
                lblvysledek.Text = num.Text;
            }
            else
            {
                lblvysledek.Text = lblvysledek.Text + num.Text;
            }
        }

        private void btnAC_Click(object sender, EventArgs e)
        {
            lblvysledek.Text = "0";
            lblpredvýsledek.Text = "0";
        }

        private void btnC_Click(object sender, EventArgs e)
        {
            lblvysledek.Text = "0";
        }

        private void btndel_Click(object sender, EventArgs e)
        {
            if (lblvysledek.Text.Length > 0)
            {
                lblvysledek.Text = lblvysledek.Text.Remove(lblvysledek.Text.Length - 1, 1);
            }

            if (lblvysledek.Text == "")
            {
                lblvysledek.Text = "0";
            }
        }

        private void btnznam_Click(object sender, EventArgs e)
        {
                znam_tmp((Button)sender);
        }

        private void btnrovno_Click(object sender, EventArgs e)
        {
            try
            {
                char znak = lblpredvýsledek.Text[lblpredvýsledek.Text.Length - 1];
                lblpredvýsledek.Text = lblpredvýsledek.Text.Remove(lblpredvýsledek.Text.Length - 1);
                double meziVysledek = vysledek(Convert.ToDouble(lblpredvýsledek.Text), Convert.ToDouble(lblvysledek.Text), znak);
                lblvysledek.Text = Convert.ToString(meziVysledek);
                lblpredvýsledek.Text = "0";
            }
            catch (Exception)
            {

                
            }
        }

        private void btnfaktorial_Click(object sender, EventArgs e)
        {
            if (lblpredvýsledek.Text == "0")
            {
                lblpredvýsledek.Text = Convert.ToString(ivsmath.Faktorial(Convert.ToDouble(lblvysledek.Text)));
            }
            else
            {
                try
                {
                    char znak = lblpredvýsledek.Text[lblpredvýsledek.Text.Length - 1];
                    lblpredvýsledek.Text = lblpredvýsledek.Text.Remove(lblpredvýsledek.Text.Length - 1);
                    double meziVysledek = vysledek(Convert.ToDouble(lblpredvýsledek.Text), ivsmath.Faktorial(Convert.ToDouble(lblvysledek.Text)), znak);
                    lblpredvýsledek.Text = Convert.ToString(meziVysledek);
                    lblvysledek.Text = "0";
                }
                catch (Exception)
                {
                    lblpredvýsledek.Text = "0";
                }
               
            }
            
        }
    }
}