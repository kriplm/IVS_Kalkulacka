var searchData=
[
  ['dispose',['Dispose',['../classKalkula_xC4_x8Dka__IVS_1_1Form1.html#acbcd4c45e771bcae22f623077e323cc5',1,'Kalkulačka_IVS::Form1']]]
];
