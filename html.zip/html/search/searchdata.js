var indexSectionsWithContent =
{
  0: "dfkpvz",
  1: "f",
  2: "k",
  3: "fp",
  4: "dfvz",
  5: "vz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Vše",
  1: "Třídy",
  2: "Prostory jmen",
  3: "Soubory",
  4: "Funkce",
  5: "Proměnné"
};

