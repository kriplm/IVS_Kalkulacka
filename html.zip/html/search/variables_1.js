var searchData=
[
  ['znam',['znam',['../classKalkula_xC4_x8Dka__IVS_1_1Form1.html#a7946b7fbb4f0853186e53fc90ef90c97',1,'Kalkulačka_IVS::Form1']]]
];
