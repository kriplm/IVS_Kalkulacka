var menudata={children:[
{text:"Hlavní stránka",url:"index.html"},
{text:"Prostory jmen",url:"namespaces.html",children:[
{text:"Seznam prostorů jmen",url:"namespaces.html"}]},
{text:"Třídy",url:"annotated.html",children:[
{text:"Seznam tříd",url:"annotated.html"},
{text:"Rejstřík tříd",url:"classes.html"},
{text:"Hierarchie tříd",url:"hierarchy.html"},
{text:"Seznam členů tříd",url:"functions.html",children:[
{text:"Vše",url:"functions.html"},
{text:"Funkce",url:"functions_func.html"},
{text:"Proměnné",url:"functions_vars.html"}]}]},
{text:"Soubory",url:"files.html",children:[
{text:"Seznam souborů",url:"files.html"}]}]}
