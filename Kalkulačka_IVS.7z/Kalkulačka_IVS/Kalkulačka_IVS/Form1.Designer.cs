﻿namespace Kalkulačka_IVS
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btn7 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btncarka = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.btnrovno = new System.Windows.Forms.Button();
            this.btnfaktorial = new System.Windows.Forms.Button();
            this.btnkrat = new System.Windows.Forms.Button();
            this.btnplus = new System.Windows.Forms.Button();
            this.btnodmocnina = new System.Windows.Forms.Button();
            this.btndeleni = new System.Windows.Forms.Button();
            this.btnminus = new System.Windows.Forms.Button();
            this.btnmodulo = new System.Windows.Forms.Button();
            this.btnC = new System.Windows.Forms.Button();
            this.btnAC = new System.Windows.Forms.Button();
            this.btndel = new System.Windows.Forms.Button();
            this.lblvysledek = new System.Windows.Forms.Label();
            this.lblpredvýsledek = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn7
            // 
            this.btn7.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.btn7.Location = new System.Drawing.Point(11, 203);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(55, 70);
            this.btn7.TabIndex = 0;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.number_click);
            // 
            // btn4
            // 
            this.btn4.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.btn4.Location = new System.Drawing.Point(11, 279);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(55, 70);
            this.btn4.TabIndex = 1;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.number_click);
            // 
            // btn1
            // 
            this.btn1.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.btn1.Location = new System.Drawing.Point(11, 355);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(55, 70);
            this.btn1.TabIndex = 2;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.number_click);
            // 
            // btn0
            // 
            this.btn0.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.btn0.Location = new System.Drawing.Point(11, 437);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(116, 70);
            this.btn0.TabIndex = 3;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = true;
            this.btn0.Click += new System.EventHandler(this.number_click);
            // 
            // btn2
            // 
            this.btn2.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.btn2.Location = new System.Drawing.Point(72, 355);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(55, 70);
            this.btn2.TabIndex = 6;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.number_click);
            // 
            // btn5
            // 
            this.btn5.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.btn5.Location = new System.Drawing.Point(72, 279);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(55, 70);
            this.btn5.TabIndex = 5;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.number_click);
            // 
            // btn8
            // 
            this.btn8.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.btn8.Location = new System.Drawing.Point(72, 203);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(55, 70);
            this.btn8.TabIndex = 4;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.number_click);
            // 
            // btn3
            // 
            this.btn3.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.btn3.Location = new System.Drawing.Point(133, 355);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(55, 70);
            this.btn3.TabIndex = 9;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.number_click);
            // 
            // btn6
            // 
            this.btn6.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.btn6.Location = new System.Drawing.Point(133, 279);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(55, 70);
            this.btn6.TabIndex = 8;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.number_click);
            // 
            // btn9
            // 
            this.btn9.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.btn9.Location = new System.Drawing.Point(133, 203);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(55, 70);
            this.btn9.TabIndex = 7;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.number_click);
            // 
            // btncarka
            // 
            this.btncarka.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.btncarka.Location = new System.Drawing.Point(133, 437);
            this.btncarka.Name = "btncarka";
            this.btncarka.Size = new System.Drawing.Size(55, 70);
            this.btncarka.TabIndex = 10;
            this.btncarka.Text = ",";
            this.btncarka.UseVisualStyleBackColor = true;
            this.btncarka.Click += new System.EventHandler(this.number_click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(1252, 90);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 11;
            this.button12.Text = "button12";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // btnrovno
            // 
            this.btnrovno.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.btnrovno.Location = new System.Drawing.Point(269, 437);
            this.btnrovno.Name = "btnrovno";
            this.btnrovno.Size = new System.Drawing.Size(135, 70);
            this.btnrovno.TabIndex = 12;
            this.btnrovno.Text = "=";
            this.btnrovno.UseVisualStyleBackColor = true;
            this.btnrovno.Click += new System.EventHandler(this.btnrovno_Click);
            // 
            // btnfaktorial
            // 
            this.btnfaktorial.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.btnfaktorial.Location = new System.Drawing.Point(269, 279);
            this.btnfaktorial.Name = "btnfaktorial";
            this.btnfaktorial.Size = new System.Drawing.Size(55, 70);
            this.btnfaktorial.TabIndex = 15;
            this.btnfaktorial.Text = "!";
            this.btnfaktorial.UseVisualStyleBackColor = true;
            this.btnfaktorial.Click += new System.EventHandler(this.btnznam_Click);
            // 
            // btnkrat
            // 
            this.btnkrat.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.btnkrat.Location = new System.Drawing.Point(208, 355);
            this.btnkrat.Name = "btnkrat";
            this.btnkrat.Size = new System.Drawing.Size(55, 70);
            this.btnkrat.TabIndex = 14;
            this.btnkrat.Text = "*";
            this.btnkrat.UseVisualStyleBackColor = true;
            this.btnkrat.Click += new System.EventHandler(this.btnznam_Click);
            // 
            // btnplus
            // 
            this.btnplus.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.btnplus.Location = new System.Drawing.Point(208, 203);
            this.btnplus.Name = "btnplus";
            this.btnplus.Size = new System.Drawing.Size(55, 70);
            this.btnplus.TabIndex = 13;
            this.btnplus.Text = "+";
            this.btnplus.UseVisualStyleBackColor = true;
            this.btnplus.Click += new System.EventHandler(this.btnznam_Click);
            // 
            // btnodmocnina
            // 
            this.btnodmocnina.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.btnodmocnina.Location = new System.Drawing.Point(269, 355);
            this.btnodmocnina.Name = "btnodmocnina";
            this.btnodmocnina.Size = new System.Drawing.Size(55, 70);
            this.btnodmocnina.TabIndex = 18;
            this.btnodmocnina.Text = "√";
            this.btnodmocnina.UseVisualStyleBackColor = true;
            this.btnodmocnina.Click += new System.EventHandler(this.btnznam_Click);
            // 
            // btndeleni
            // 
            this.btndeleni.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.btndeleni.Location = new System.Drawing.Point(208, 437);
            this.btndeleni.Name = "btndeleni";
            this.btndeleni.Size = new System.Drawing.Size(55, 70);
            this.btndeleni.TabIndex = 17;
            this.btndeleni.Text = "/";
            this.btndeleni.UseVisualStyleBackColor = true;
            this.btndeleni.Click += new System.EventHandler(this.btnznam_Click);
            // 
            // btnminus
            // 
            this.btnminus.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.btnminus.Location = new System.Drawing.Point(208, 279);
            this.btnminus.Name = "btnminus";
            this.btnminus.Size = new System.Drawing.Size(55, 70);
            this.btnminus.TabIndex = 16;
            this.btnminus.Text = "-";
            this.btnminus.UseVisualStyleBackColor = true;
            this.btnminus.Click += new System.EventHandler(this.btnznam_Click);
            // 
            // btnmodulo
            // 
            this.btnmodulo.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.btnmodulo.Location = new System.Drawing.Point(269, 203);
            this.btnmodulo.Name = "btnmodulo";
            this.btnmodulo.Size = new System.Drawing.Size(55, 70);
            this.btnmodulo.TabIndex = 21;
            this.btnmodulo.Text = "%";
            this.btnmodulo.UseVisualStyleBackColor = true;
            this.btnmodulo.Click += new System.EventHandler(this.btnznam_Click);
            // 
            // btnC
            // 
            this.btnC.Font = new System.Drawing.Font("Arial Black", 16F, System.Drawing.FontStyle.Bold);
            this.btnC.Location = new System.Drawing.Point(330, 279);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(74, 70);
            this.btnC.TabIndex = 20;
            this.btnC.Text = "C";
            this.btnC.UseVisualStyleBackColor = true;
            this.btnC.Click += new System.EventHandler(this.btnC_Click);
            // 
            // btnAC
            // 
            this.btnAC.Font = new System.Drawing.Font("Arial Black", 16F, System.Drawing.FontStyle.Bold);
            this.btnAC.Location = new System.Drawing.Point(330, 203);
            this.btnAC.Name = "btnAC";
            this.btnAC.Size = new System.Drawing.Size(74, 70);
            this.btnAC.TabIndex = 19;
            this.btnAC.Text = "AC";
            this.btnAC.UseVisualStyleBackColor = true;
            this.btnAC.Click += new System.EventHandler(this.btnAC_Click);
            // 
            // btndel
            // 
            this.btndel.Font = new System.Drawing.Font("Arial Black", 16F, System.Drawing.FontStyle.Bold);
            this.btndel.Location = new System.Drawing.Point(330, 355);
            this.btndel.Name = "btndel";
            this.btndel.Size = new System.Drawing.Size(74, 70);
            this.btndel.TabIndex = 22;
            this.btndel.Text = "DEL";
            this.btndel.UseVisualStyleBackColor = true;
            this.btndel.Click += new System.EventHandler(this.btndel_Click);
            // 
            // lblvysledek
            // 
            this.lblvysledek.AutoSize = true;
            this.lblvysledek.Font = new System.Drawing.Font("Arial Black", 30F, System.Drawing.FontStyle.Bold);
            this.lblvysledek.Location = new System.Drawing.Point(15, 95);
            this.lblvysledek.Name = "lblvysledek";
            this.lblvysledek.Size = new System.Drawing.Size(51, 56);
            this.lblvysledek.TabIndex = 23;
            this.lblvysledek.Text = "0";
            this.lblvysledek.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblpredvýsledek
            // 
            this.lblpredvýsledek.AutoSize = true;
            this.lblpredvýsledek.Font = new System.Drawing.Font("Arial Black", 18F, System.Drawing.FontStyle.Bold);
            this.lblpredvýsledek.Location = new System.Drawing.Point(19, 32);
            this.lblpredvýsledek.Name = "lblpredvýsledek";
            this.lblpredvýsledek.Size = new System.Drawing.Size(31, 33);
            this.lblpredvýsledek.TabIndex = 24;
            this.lblpredvýsledek.Text = "0";
            this.lblpredvýsledek.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(426, 514);
            this.Controls.Add(this.lblpredvýsledek);
            this.Controls.Add(this.lblvysledek);
            this.Controls.Add(this.btndel);
            this.Controls.Add(this.btnmodulo);
            this.Controls.Add(this.btnC);
            this.Controls.Add(this.btnAC);
            this.Controls.Add(this.btnodmocnina);
            this.Controls.Add(this.btndeleni);
            this.Controls.Add(this.btnminus);
            this.Controls.Add(this.btnfaktorial);
            this.Controls.Add(this.btnkrat);
            this.Controls.Add(this.btnplus);
            this.Controls.Add(this.btnrovno);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.btncarka);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn7);
            this.Font = new System.Drawing.Font("Arial Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Kalkulačka";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btncarka;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button btnrovno;
        private System.Windows.Forms.Button btnfaktorial;
        private System.Windows.Forms.Button btnkrat;
        private System.Windows.Forms.Button btnplus;
        private System.Windows.Forms.Button btnodmocnina;
        private System.Windows.Forms.Button btndeleni;
        private System.Windows.Forms.Button btnminus;
        private System.Windows.Forms.Button btnmodulo;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Button btnAC;
        private System.Windows.Forms.Button btndel;
        private System.Windows.Forms.Label lblvysledek;
        private System.Windows.Forms.Label lblpredvýsledek;
    }
}

